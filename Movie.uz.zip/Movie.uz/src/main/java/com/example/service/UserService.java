package com.example.service;


import com.example.dto.user.UserCreateDto;
import com.example.dto.user.UserDetailDto;
import com.example.enums.UserStatus;
import com.example.movieuz.User;
import com.example.repository.UserRepository;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;


@Getter
@Setter
@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public void create(UserCreateDto dto) {
        User entity = new User();
        convertDtoToEntity(dto, entity);
        entity.setStatus(UserStatus.INACTIVE);
        entity.setCreatedAt(LocalDateTime.now());
        userRepository.save(entity);
    }

    public UserDetailDto get(UUID id){
        User entity = getEntity(id);

        UserDetailDto dto = new UserDetailDto();

       return convertEntityToDto(entity, dto);

    }


    public User getEntity(UUID id) {
        Optional<User> optional = userRepository.findById(id);
        if (optional.isEmpty()){
            throw new IllegalArgumentException();
        }
        return optional.get();
    }

    public void update(UUID id, UserCreateDto dto) {
        User entity =  getEntity(id);;
        convertDtoToEntity(dto, entity);
        entity.setUpdatedAt(LocalDateTime.now());
        userRepository.save(entity);
    }

    public UserDetailDto convertEntityToDto(User entity, UserDetailDto dto){
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        dto.setSurname(entity.getSurname());
        dto.setEmail(entity.getEmail());
        dto.setBirthDate(entity.getBirthDate());
        dto.setImageURL(entity.getImageURL());
        dto.setGender(entity.getGender());
        dto.setAddress(entity.getAddress());
        dto.setCity(entity.getCity());
        return dto;
    }
    public void convertDtoToEntity(UserCreateDto dto, User entity) {
        entity.setName(dto.getName());
        entity.setSurname(dto.getSurname());
        entity.setEmail(dto.getEmail());
        entity.setPassword(dto.getPassword());
        entity.setBirthDate(dto.getBirtDate());
        entity.setImageURL(dto.getImageURl());
        entity.setGender(dto.getGender());
        entity.setAddress(dto.getAddress());
        entity.setCity(dto.getCity());
    }

    public void delete(UUID id){
        getEntity(id);
        userRepository.deleteById(id);
    }

    public List<UserDetailDto> getAll(){
        List<User> users = userRepository.findAll();
        List<UserDetailDto> dtos = new ArrayList<>();
        for (User user: users) {
            dtos.add(convertEntityToDto(user, new UserDetailDto()));
        }
        return dtos;
    }


}
