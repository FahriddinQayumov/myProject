package com.example.service;


import com.example.movieuz.News;
import com.example.movieuz.NewsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class MovieService {

    @Autowired
    private NewsRepository newsRepository;

    public News create(News news) {
        newsRepository.save(news);
        return news;
    }

    public News get(UUID id){
        Optional<News> optional = newsRepository.findById(id);
        if (optional.isEmpty()){
            throw new IllegalArgumentException("News not found");
        }
        return optional.get();
    }


    public News update(UUID id, News news) {
        get(id);
        news.setId(id);
        newsRepository.save(news);
        return news;
    }

    public String delete(UUID id) {
        get(id);
        newsRepository.deleteById(id);
        return "deleted";
    }

    public List<News> getAll() {
        return newsRepository.findAll();
    }
}



