package com.example.movieuz;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;


@Getter
@Setter

@Entity
@Table(name = ("news"))
public class News {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;
    private String title;
    private String content;
    @Column(name = ("published_at"))
    private LocalDateTime publishedAt;
    @ManyToOne
    @JoinColumn(name = ("publisher_id"), insertable = false, updatable = false)
    private User publisher;

    @Column(name = ("publisher_id"))
    private UUID pulisherId;
}
