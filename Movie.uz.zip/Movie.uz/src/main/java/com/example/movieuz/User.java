package com.example.movieuz;

import com.example.enums.City;
import com.example.enums.Gender;
import com.example.enums.UserStatus;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter

@Entity
@Table(name = ("users"))
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;
    @Column(name = ("name"))
    private String name;
    private String surname;
    private String email;
    private String password;
    @Enumerated(EnumType.STRING)
    private Gender gender;
    @Column(name = ("birth_date"))
    private LocalDate birthDate;
    @Column(name = ("image_url"))
    private String imageURL;
    @Enumerated(EnumType.STRING)
    private UserStatus status;
    private String address;
    @Enumerated(EnumType.STRING)
    private City city;
    @Column(name = ("created_at"))
    private LocalDateTime createdAt;
    @Column(name = ("updated_at"))
    private LocalDateTime updatedAt;



}
