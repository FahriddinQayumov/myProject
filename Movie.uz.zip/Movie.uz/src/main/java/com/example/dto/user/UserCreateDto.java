package com.example.dto.user;


import com.example.enums.City;
import com.example.enums.Gender;
import com.sun.istack.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import java.time.LocalDate;

@Getter
@Setter
public class UserCreateDto {
    @NotBlank(message = "Invalide name")
    private String name;
    @NotBlank(message = "Invalide surname")
    private String surname;
    @Email(message = "Invalide email")
    private String email;
    @NotBlank(message = "Invalide passvord")
    @Length(min = 8, max = 30)
    private String password;
    private LocalDate birtDate;
    private String imageURl;
    private String address;
    @NotBlank(message = "Invalide address")
    private Gender gender;
    private City city;
}
