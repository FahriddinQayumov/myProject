package com.example.dto.movie;

import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
public class MovieDetailDto {
    private UUID id;
    private String name;
    private String decription;
}
