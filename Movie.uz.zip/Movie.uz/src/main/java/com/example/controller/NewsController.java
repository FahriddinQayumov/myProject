package com.example.controller;


import com.example.movieuz.News;
import com.example.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/news")
public class NewsController {

    @Autowired
    private MovieService newsService;

    @GetMapping("{id}")
    private ResponseEntity<?> get(@PathVariable("id")UUID id){
        News response = newsService.get(id);
        return ResponseEntity.ok(response);
    }

    @PostMapping()

    private ResponseEntity<?> create(@RequestBody News news){
        News result = newsService.create(news);
        return ResponseEntity.ok(result);
    }


    @PutMapping("/{id}")

    public ResponseEntity<?> update(@PathVariable("id")UUID id, @RequestBody News news){
        News response = newsService.update(id, news);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{id}")

    public ResponseEntity<?> delete(@PathVariable("id")UUID id){
        String response = newsService.delete(id);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<?> getAll(){
        List<News> response = newsService.getAll();
        return ResponseEntity.ok(response);
    }
}
