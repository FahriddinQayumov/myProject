package com.example.enums;

import net.bytebuddy.dynamic.TypeResolutionStrategy;

public enum UserStatus {
    ACTIVE, INACTIVE, BLOCKED
}
