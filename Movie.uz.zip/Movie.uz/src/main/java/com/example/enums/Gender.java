package com.example.enums;

public enum Gender {
    FEMALE, MALE
}
